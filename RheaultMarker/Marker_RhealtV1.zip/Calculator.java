import java.rmi.RemoteException;

public class Calculator implements CalculatorIF {

    public int add(int x, int y) throws RemoteException {
        return x + y;
    }

    public int sub(int x, int y) throws RemoteException {
        return x - y;
    }

    public float mul(int x, int y) throws RemoteException {
        return (float) x * y;
    }

    public float div(int x, int y) throws RemoteException {
        return (float) x / y;
    }
}