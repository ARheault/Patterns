import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

class Main {
    private static final String name = "Calculator";

    public static void main(String[] args) {
        try {
            Registry registery = LocateRegistry.getRegistry(name);
            CalculatorIF theCalc = (CalculatorIF) registery.lookup(name);
            System.out.println("1 + 2 = " + theCalc.add(1, 2));
        } catch (Exception e) {
            System.err.println("Exception in the client: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
