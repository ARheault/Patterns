import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;

public class Server {
    public static void main(String[] args) {
        try {
            CalculatorIF theCalc = new Calculator();
            CalculatorIF toExport = (CalculatorIF) UnicastRemoteObject.exportObject(theCalc, 0);
            Registry registery = LocateRegistry.getRegistry();
            registery.bind("Calculator", toExport);
            System.out.println("Server up!");
        } catch (Exception e) {
            System.err.println("Server exception: " + e.getMessage());
            e.printStackTrace();
        }
    }
}