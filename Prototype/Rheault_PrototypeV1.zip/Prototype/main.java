import java.util.*;
import pattpack.account.*;

class Main {
    public static void main(String[] ignore) {
        System.out.print("Please enter an account loginID, 0-1999 for economy, 2000-3999 for standard, and 4000-5999 for professional:");
        Scanner in = new Scanner(System.in);
        int loginId = in.nextInt();
        Prototype thePrototype = Builder.build(loginId);
        System.out.println(thePrototype);
        User aUser = thePrototype.makeUser();
        System.out.println(aUser);
        in.close();
    }
}