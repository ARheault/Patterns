import pattpack.account.SecurityManagerIF;
import pattpack.account.*;

public class Prototype {
    private AccountIF accountType;
    private SecurityManagerIF securityManagerType;

   Prototype(AccountIF accountType, SecurityManagerIF securityManagerType){
        this.accountType = accountType;
        this.securityManagerType = securityManagerType;
   } 

   public User makeUser(){
        if(accountType != null && securityManagerType != null){
            return new User(accountType, securityManagerType);
        }
        else{
            System.err.println("Error: No account and security type specififed when trying to create user!");
            return null;
        }
   }
}
