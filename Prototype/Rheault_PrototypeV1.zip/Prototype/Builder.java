import pattpack.account.*;

public class Builder {
        /**
         * This method is used to put the correct products in the prototype so that the user doesn't have to see the implementation.
         * @param loginId Represents the loginID of the user.
         * @return
         */
        public static Prototype build(int loginId){
        // For this I will use the same numbers used by the professor.
        if(loginId > 0 && loginId < 1999){
            return new Prototype(new AccountEconomy(loginId), new SecurityManagerEconomy());
        }
        else{
            if(loginId > 1999 && loginId < 3999){
                return new Prototype(new AccountStandard(loginId), new SecurityManagerStandard());
            }
            else{
                if(loginId > 3999 && loginId < 5999){
                    return new Prototype(new AccountProfessional(loginId), new SecurityManagerProfessional());
                }
                else{
                    System.err.println("Invalid input!");
                    return null;
                }
            }
        }
    }
}