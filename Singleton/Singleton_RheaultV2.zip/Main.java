import java.io.IOException;

public class Main {
    public static void main(String[] args) {
        log("started");
        log("testing for formatting");
        log("just writing this because going back and doing these homeworks is actually pretty fun");
        log("Thanks again for the feedback, I definitely think it forced me to have a cleaner implementation");
        log("ended");
    }

    static void log(String tolog) {
        Logger.getInstance().log(tolog);
    }
}