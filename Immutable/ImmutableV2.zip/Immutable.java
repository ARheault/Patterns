public interface Immutable {

    /**
     * Return the x value assolciated with thePosition object.
     */
    public int getX();
    /**
     * Return the y value assolciated with thePosition object.
     */
    public int getY();
}